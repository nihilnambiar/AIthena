const admin = require('firebase-admin');
const { getFirestore, doc, getDoc } = require('firebase-admin/firestore');
const bcrypt = require('bcryptjs');
const { signSession } = require('./utils/session');

if (!admin.apps.length) {
  admin.initializeApp();
}
const db = getFirestore();

exports.handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  const { email, password } = JSON.parse(event.body || '{}');
  if (!email || !password) {
    return { statusCode: 400, body: 'Missing email or password' };
  }
  // Find user by email
  const usersRef = db.collection('users');
  const snapshot = await usersRef.where('email', '==', email).limit(1).get();
  if (snapshot.empty) {
    return { statusCode: 401, body: 'Invalid credentials' };
  }
  const userDoc = snapshot.docs[0];
  const user = userDoc.data();
  // Check password
  if (!user.passwordHash || !bcrypt.compareSync(password, user.passwordHash)) {
    return { statusCode: 401, body: 'Invalid credentials' };
  }
  // Set session cookie
  const token = signSession(user);
  return {
    statusCode: 200,
    headers: {
      'Set-Cookie': `dreamdive_session=${token}; Max-Age=604800; HttpOnly; Path=/; SameSite=Lax; Secure`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ success: true, user: { email: user.email, name: user.name, photo: user.photo, premium: !!user.premium } })
  };
}; 