const { clearSessionCookie } = require('./utils/session');

exports.handler = async (event, context) => {
  return {
    statusCode: 200,
    headers: {
      'Set-Cookie': 'dreamdive_session=; Max-Age=0; HttpOnly; Path=/; SameSite=Lax; Secure',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ success: true })
  };
}; 