const { GoogleGenerativeAI } = require("@google/generative-ai");

exports.handler = async function(event, context) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  if (!process.env.GEMINI_API_KEY) {
    console.error("GEMINI_API_KEY is missing in environment variables.");
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Gemini API key is not configured on the server." })
    };
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  const { dream, mood, isDetailed } = body;
  if (!dream) {
    return { statusCode: 400, body: JSON.stringify({ error: "Dream is required." }) };
  }

  try {
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro-latest" });

    let prompt;
    if (isDetailed) {
      prompt = `You are an expert dream analyst with deep knowledge of psychology, symbolism, and Jungian archetypes. Provide a comprehensive analysis of this dream: "${dream}" considering the user's mood: "${mood}".

Please structure your response with the following sections:

1. **SYMBOLISM ANALYSIS** (2-3 paragraphs)
   - Identify key symbols, objects, colors, and actions
   - Explain their psychological and cultural meanings
   - Connect symbols to universal archetypes

2. **EMOTIONAL TREND ANALYSIS** (2-3 paragraphs)
   - Analyze the emotional undertones and patterns
   - Connect to the user's current mood and life circumstances
   - Identify recurring emotional themes

3. **PSYCHOLOGICAL INTERPRETATION** (2-3 paragraphs)
   - Deep dive into subconscious messages
   - Explore potential unresolved issues or desires
   - Connect to personal growth opportunities

4. **REAL-LIFE CONNECTIONS** (1-2 paragraphs)
   - Suggest possible connections to waking life
   - Identify patterns or situations that might be reflected

5. **ACTIONABLE INSIGHTS** (1-2 paragraphs)
   - Provide practical advice or next steps
   - Suggest areas for self-reflection or growth
   - Offer positive affirmations or mindset shifts

Make the analysis insightful, compassionate, and empowering. Use clear language while maintaining depth.`;
    } else {
      prompt = `You are a dream interpreter. Analyze the following dream: "${dream}" and provide a meaningful interpretation considering the user's mood: "${mood}". Keep it concise but insightful, focusing on the main themes and possible meanings.`;
    }

    const result = await model.generateContent(prompt);
    const response = result.response;
    const interpretation = response.text();

    return {
      statusCode: 200,
      body: JSON.stringify({ interpretation }),
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    // In development, return the error message for easier debugging
    const isDev = process.env.NODE_ENV !== "production";
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Something went wrong while interpreting your dream.",
        ...(isDev && { details: error.message || String(error) })
      }),
    };
  }
}; 