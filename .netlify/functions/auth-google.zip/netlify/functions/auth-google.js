const { OAuth2Client } = require('google-auth-library');

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const GOOGLE_REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI; // e.g. https://thedreamdive.com/.netlify/functions/auth-google-callback

exports.handler = async (event, context) => {
  const client = new OAuth2Client(
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI
  );

  const url = client.generateAuthUrl({
    access_type: 'offline',
    scope: [
      'profile',
      'email'
    ],
    prompt: 'select_account',
  });

  return {
    statusCode: 302,
    headers: {
      Location: url
    },
    body: ''
  };
}; 