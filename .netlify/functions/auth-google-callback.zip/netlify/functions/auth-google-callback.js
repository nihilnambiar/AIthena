const { OAuth2Client } = require('google-auth-library');
const { getFirestore, doc, getDoc, setDoc } = require('firebase-admin/firestore');
const admin = require('firebase-admin');
const { signSession, setSessionCookie } = require('./utils/session');

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const GOOGLE_REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI;

if (!admin.apps.length) {
  admin.initializeApp();
}
const db = getFirestore();

exports.handler = async (event, context) => {
  const url = new URL(event.rawUrl);
  const code = url.searchParams.get('code');
  if (!code) {
    return { statusCode: 400, body: 'Missing code' };
  }

  const client = new OAuth2Client(
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI
  );

  const { tokens } = await client.getToken(code);
  client.setCredentials(tokens);
  const ticket = await client.verifyIdToken({ idToken: tokens.id_token, audience: GOOGLE_CLIENT_ID });
  const payload = ticket.getPayload();

  // User info
  const user = {
    uid: payload.sub,
    email: payload.email,
    name: payload.name,
    photo: payload.picture,
    premium: false
  };

  // Create user in Firestore if not exists
  const userRef = doc(db, 'users', user.uid);
  const snap = await getDoc(userRef);
  if (!snap.exists) {
    await setDoc(userRef, user);
  }

  // Set session cookie
  const token = signSession(user);

  return {
    statusCode: 302,
    headers: {
      'Set-Cookie': `dreamdive_session=${token}; Max-Age=604800; HttpOnly; Path=/; SameSite=Lax; Secure`,
      Location: '/'
    },
    body: ''
  };
}; 