const dreamSymbolMap = {
  flying: "Dreams of flying often symbolize a desire for freedom or escape from limitations.",
  cat: "Cats in dreams can represent intuition, independence, or feminine energy.",
  water: "Water often symbolizes emotions, the subconscious, or a need for cleansing.",
  falling: "Falling dreams may reflect anxiety, loss of control, or fear of failure.",
  mirror: "Mirrors can symbolize self-reflection, identity, or seeing yourself clearly.",
  key: "A key in a dream may represent access to new opportunities or unlocking hidden potential.",
  library: "A library can symbolize knowledge, wisdom, or a search for answers.",
  snake: "Snakes often represent transformation, hidden fears, or healing.",
  baby: "Babies can symbolize new beginnings, innocence, or vulnerability.",
  teeth: "Losing teeth in dreams may reflect concerns about appearance or powerlessness."
};

function ruleBasedInterpretation(dream) {
  const found = [];
  const lowerDream = dream.toLowerCase();
  for (const symbol in dreamSymbolMap) {
    if (lowerDream.includes(symbol)) {
      found.push(dreamSymbolMap[symbol]);
    }
  }
  if (found.length === 0) {
    return "No common dream symbols found. Your dream is unique! Try to reflect on your feelings and recent experiences.";
  }
  return found.join("\n\n");
}

exports.handler = async function(event, context) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  const { dream } = body;
  if (!dream) {
    return { statusCode: 400, body: JSON.stringify({ error: "Dream is required." }) };
  }
  const interpretation = ruleBasedInterpretation(dream);
  return {
    statusCode: 200,
    body: JSON.stringify({ interpretation })
  };
}; 