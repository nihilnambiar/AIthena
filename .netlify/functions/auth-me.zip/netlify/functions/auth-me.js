const { verifySession, getSessionFromRequest } = require('./utils/session');

exports.handler = async (event, context) => {
  const token = getSessionFromRequest(event);
  const user = token ? verifySession(token) : null;
  if (!user) {
    return { statusCode: 401, body: JSON.stringify({ user: null }) };
  }
  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user })
  };
}; 