const GROQ_API_KEY = "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";
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const MODEL = "llama3-70b-8192"; // Llama 3 70B, adjust if you want a smaller model

const SHORT_PROMPT = `You are an expert dream interpreter. Given a user's dream and their mood, provide a concise, insightful interpretation in 2-3 sentences. Focus on the main symbolism and possible real-life connection. Match the tone and style of your response to the user's mood (e.g., if the mood is 'scary', be reassuring; if 'peaceful', be gentle and calm; if 'funny', be lighthearted, etc). Be brief, clear, and positive.`;

const DETAILED_PROMPT = `You are an expert dream analyst with deep knowledge of psychology, symbolism, and Jungian archetypes. Given a user's dream and their mood, provide a comprehensive, multi-paragraph analysis, including:

1. Symbolism analysis (explain key symbols, objects, colors, and actions)
2. Emotional trends (analyze emotional undertones and patterns)
3. Psychological interpretation (subconscious messages, unresolved issues, personal growth)
4. Real-life connections (suggest possible connections to waking life)
5. Actionable insights (practical advice, self-reflection, affirmations)

Match the tone and style of your response to the user's mood (e.g., if the mood is 'scary', be reassuring; if 'peaceful', be gentle and calm; if 'funny', be lighthearted, etc). Make the analysis insightful, compassionate, and empowering. Use clear language while maintaining depth.`;

exports.handler = async function(event, context) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  const { dream, mood, detailed } = body;
  if (!dream) {
    return { statusCode: 400, body: JSON.stringify({ error: "Dream is required." }) };
  }

  const prompt = detailed ? DETAILED_PROMPT : SHORT_PROMPT;
  const max_tokens = detailed ? 700 : 200;

  try {
    const response = await fetch(GROQ_API_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${GROQ_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: prompt },
          { role: "user", content: `Dream: ${dream}\nMood: ${mood}` }
        ],
        max_tokens,
        temperature: 0.7
      })
    });
    if (!response.ok) {
      const errorText = await response.text();
      return { statusCode: response.status, body: JSON.stringify({ error: "Groq API error", details: errorText }) };
    }
    const data = await response.json();
    const interpretation = data.choices?.[0]?.message?.content || "No interpretation returned.";
    return {
      statusCode: 200,
      body: JSON.stringify({ interpretation })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to interpret dream.", details: err.message })
    };
  }
}; 